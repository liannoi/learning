﻿namespace IoCExample.Library
{
    public interface IBusinessLogic
    {
        void Process();
    }
}