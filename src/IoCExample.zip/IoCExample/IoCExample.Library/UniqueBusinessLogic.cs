﻿using IoCExample.Library.Utilities;
using System;

namespace IoCExample.Library
{
    public class UniqueBusinessLogic : IBusinessLogic
    {
        private readonly ILogger _logger;
        private readonly IDataAccess _dataAccess;

        public UniqueBusinessLogic(ILogger logger, IDataAccess dataAccess)
        {
            _logger = logger;
            _dataAccess = dataAccess;
        }

        public void Process()
        {
            Console.WriteLine("I'M UNIQUE!");
            _logger.WriteLine("Начало обработки данных.");
            Console.WriteLine("Обработка данных");
            _dataAccess.Load();
            _dataAccess.Save(DateTime.Now.ToString());
            _logger.WriteLine("Конец обработки данных.");
        }
    }
}
