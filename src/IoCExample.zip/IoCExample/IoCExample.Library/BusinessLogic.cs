﻿using System;
using IoCExample.Library.Utilities;

namespace IoCExample.Library
{
    public class BusinessLogic : IBusinessLogic
    {
        private readonly ILogger _logger;
        private readonly IDataAccess _dataAccess;

        public BusinessLogic(ILogger logger, IDataAccess dataAccess)
        {
            _logger = logger;
            _dataAccess = dataAccess;
        }

        public void Process()
        {
            _logger.WriteLine("Начало обработки данных.");
            Console.WriteLine("Обработка данных");
            _dataAccess.Load();
            _dataAccess.Save(DateTime.Now.ToString());
            _logger.WriteLine("Конец обработки данных.");
        }
    }
}