﻿namespace IoCExample.Library.Utilities
{
    public interface IDataAccess
    {
        void Load();
        void Save(string name);
    }
}