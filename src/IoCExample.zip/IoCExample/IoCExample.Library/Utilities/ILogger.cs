﻿namespace IoCExample.Library.Utilities
{
    public interface ILogger
    {
        void WriteLine(string message);
    }
}