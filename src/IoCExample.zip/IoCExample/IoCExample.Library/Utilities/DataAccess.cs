﻿using System;

namespace IoCExample.Library.Utilities
{
    public class DataAccess : IDataAccess
    {
        private readonly ILogger _logger;

        public DataAccess(ILogger logger)
        {
            _logger = logger;
        }

        public void Load()
        {
            Console.WriteLine("Loading Data...");
            _logger.WriteLine("LOAD");
        }

        public void Save(string name)
        {
            Console.WriteLine($"Saving {name}...");
            _logger.WriteLine("SAVE");
        }
    }
}