﻿using System;

namespace IoCExample.Library.Utilities
{
    public class Logger : ILogger
    {
        public void WriteLine(string message)
        {
            Console.WriteLine($"LOG: {message}");
        }
    }
}