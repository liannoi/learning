﻿using Autofac;
using System;
using System.Text;

namespace IoCExample.ConsoleUI
{
    internal static class Program
    {
        private static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            IContainer container = ContainerConfig.Configure();
            using (ILifetimeScope scope = container.BeginLifetimeScope())
            {
                IApplication application = scope.Resolve<IApplication>();
                application.Run();
            }
        }
    }
}