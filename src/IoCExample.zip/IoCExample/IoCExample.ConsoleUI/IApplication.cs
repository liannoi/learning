﻿namespace IoCExample.ConsoleUI
{
    public interface IApplication
    {
        void Run();
    }
}